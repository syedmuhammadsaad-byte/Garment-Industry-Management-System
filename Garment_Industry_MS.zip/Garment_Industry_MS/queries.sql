-- CostSheet Module
CREATE TABLE CostSheet (
    CostSheetID INT PRIMARY KEY,
    JobID INT,
    BuyerID INT,
    Style VARCHAR(50),
    Quantity INT,
    SizeRange VARCHAR(50),
    Cutting DECIMAL(10, 2),
    Embroidery DECIMAL(10, 2),
    Overheads DECIMAL(10, 2),
    Commission DECIMAL(10, 2),
    FreightTrain DECIMAL(10, 2),
    Total DECIMAL(10, 2),
    Target DECIMAL(10, 2),
    UserID INT,
    FactoryID INT
);

CREATE TABLE Job (
    JobID INT PRIMARY KEY,
    JobDescription VARCHAR(255),
    JobStatus VARCHAR(50)
);

CREATE TABLE Buyer (
    BuyerID INT PRIMARY KEY,
    BuyerName VARCHAR(100),
    BuyerEmail VARCHAR(100),
    BuyerAddress VARCHAR(255),
    BuyerTelNo VARCHAR(50),
    BuyerCurrency VARCHAR(10)
);

CREATE TABLE Fabrics (
    FabricID INT PRIMARY KEY,
    FabricType VARCHAR(50),
    FabricDescription VARCHAR(255),
    FabricQuantity INT,
    FabricRate DECIMAL(10, 2),
    CostSheetID INT,
    FOREIGN KEY (CostSheetID) REFERENCES CostSheet(CostSheetID)
);

CREATE TABLE Accessories (
    AccessoryID INT PRIMARY KEY,
    AccessoryItem VARCHAR(50),
    AccessoryRate DECIMAL(10, 2),
    AccessoryQuantity INT,
    CostSheetID INT,
    FOREIGN KEY (CostSheetID) REFERENCES CostSheet(CostSheetID)
);


-- Users module
CREATE TABLE Roles (
    RoleID INT PRIMARY KEY,
    Role VARCHAR(50),
    RoleCount INT
);

CREATE TABLE Rights (
    Role VARCHAR(50) PRIMARY KEY,
    Rights TEXT
);

CREATE TABLE UserLogs (
    LoginID INT PRIMARY KEY,
    SessionKey VARCHAR(50)
);

CREATE TABLE Session (
    SessionKey VARCHAR(50) PRIMARY KEY,
    LoginTime TIMESTAMP,
    LogoutTime TIMESTAMP
);

CREATE TABLE User (
    UserID INT PRIMARY KEY,
    Username VARCHAR(50),
    Password VARCHAR(50),
    Status VARCHAR(20),
    RoleID INT,
    LoginID INT,
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID),
    FOREIGN KEY (LoginID) REFERENCES UserLogs(LoginID)
);

-- OrderDetails Module
CREATE TABLE PurchaseOrder (
    POID INT PRIMARY KEY,
    UserID INT,
    JobID INT,
    BuyerID INT,
    FactoryID INT,
    Item VARCHAR(50),
    Style VARCHAR(50),
    Color VARCHAR(20),
    Quantity INT,
    OrderDt DATE,
    POPrice DECIMAL(10, 2)
);

CREATE TABLE PackList (
    PackListID INT PRIMARY KEY,
    ShipQty INT,
    ShipMode VARCHAR(20),
    DeliveryDays INT,
    ETD DATE,
    PLPrice DECIMAL(10, 2)
);

CREATE TABLE Factory (
    FactoryID INT PRIMARY KEY,
    FactoryName VARCHAR(100),
    FactoryAddress VARCHAR(255),
    FactoryEmail VARCHAR(100),
    FactoryContactPerson VARCHAR(100),
    FactoryTelNo VARCHAR(50),
    FactoryProduct VARCHAR(50)
);

CREATE TABLE OrderDetails (
    POID INT,
    PackListID INT,
    PriceDiff DECIMAL(10, 2),
    DeliveryDt DATE,
    TransitDays INT,
    PRIMARY KEY (POID, PackListID),
    FOREIGN KEY (POID) REFERENCES PurchaseOrder(POID),
    FOREIGN KEY (PackListID) REFERENCES PackList(PackListID)
);


INSERT INTO CostSheet (CostSheetID, JobID, BuyerID, Style, Quantity, SizeRange, Cutting, Embroidery, Overheads, Commission, FreightTrain, Total, Target, UserID, FactoryID) 
VALUES 
(1, 101, 1001, 'Casual', 500, 'M-L', 100.00, 200.00, 150.00, 50.00, 30.00, 530.00, 600.00, 1, 201),
(2, 102, 1002, 'Formal', 300, 'S-M', 80.00, 150.00, 100.00, 30.00, 20.00, 380.00, 450.00, 2, 202),
(3, 103, 1003, 'Sportswear', 700, 'L-XL', 120.00, 250.00, 170.00, 60.00, 40.00, 640.00, 700.00, 3, 203),
(4, 104, 1004, 'Evening Dress', 150, 'S-L', 200.00, 300.00, 200.00, 80.00, 50.00, 830.00, 900.00, 4, 204),
(5, 105, 1005, 'Jackets', 400, 'M-XL', 150.00, 220.00, 180.00, 70.00, 35.00, 655.00, 720.00, 5, 205),
(6, 106, 1006, 'Sweaters', 600, 'S-M', 130.00, 180.00, 160.00, 55.00, 25.00, 550.00, 620.00, 6, 206),
(7, 107, 1007, 'Skirts', 350, 'L-XL', 110.00, 170.00, 140.00, 40.00, 20.00, 480.00, 540.00, 7, 207),
(8, 108, 1008, 'Trousers', 500, 'M-L', 90.00, 160.00, 130.00, 45.00, 30.00, 455.00, 520.00, 8, 208),
(9, 109, 1009, 'Suits', 200, 'S-M', 220.00, 320.00, 240.00, 85.00, 60.00, 925.00, 1000.00, 9, 209),
(10, 110, 1010, 'Shorts', 450, 'L-XL', 100.00, 140.00, 150.00, 50.00, 25.00, 465.00, 520.00, 10, 210);

INSERT INTO Job (JobID, JobDescription, JobStatus) 
VALUES 
(101, 'Job for casual wear production', 'In Progress'),
(102, 'Job for formal wear production', 'Completed'),
(103, 'Job for sportswear production', 'In Progress'),
(104, 'Job for evening dress production', 'Pending'),
(105, 'Job for jackets production', 'In Progress'),
(106, 'Job for sweaters production', 'Completed'),
(107, 'Job for skirts production', 'Pending'),
(108, 'Job for trousers production', 'In Progress'),
(109, 'Job for suits production', 'Completed'),
(110, 'Job for shorts production', 'Pending');

INSERT INTO Buyer (BuyerID, BuyerName, BuyerEmail, BuyerAddress, BuyerTelNo, BuyerCurrency) 
VALUES 
(1001, 'Buyer One', 'buyer.one@company.com', '123 Market St', '555-1234', 'USD'),
(1002, 'Buyer Two', 'buyer.two@company.com', '456 Broad St', '555-5678', 'EUR'),
(1003, 'Buyer Three', 'buyer.three@company.com', '789 High St', '555-9012', 'GBP'),
(1004, 'Buyer Four', 'buyer.four@company.com', '321 Oak St', '555-3456', 'AUD'),
(1005, 'Buyer Five', 'buyer.five@company.com', '654 Pine St', '555-7890', 'CAD'),
(1006, 'Buyer Six', 'buyer.six@company.com', '987 Cedar St', '555-2345', 'JPY'),
(1007, 'Buyer Seven', 'buyer.seven@company.com', '159 Maple St', '555-6781', 'CHF'),
(1008, 'Buyer Eight', 'buyer.eight@company.com', '753 Elm St', '555-9018', 'CNY'),
(1009, 'Buyer Nine', 'buyer.nine@company.com', '852 Birch St', '555-4567', 'INR'),
(1010, 'Buyer Ten', 'buyer.ten@company.com', '963 Willow St', '555-7894', 'SGD');

INSERT INTO Fabrics (FabricID, FabricType, FabricDescription, FabricQuantity, FabricRate, CostSheetID) 
VALUES 
(1, 'Cotton', 'High quality cotton', 200, 5.00, 1),
(2, 'Silk', 'Premium quality silk', 100, 10.00, 2),
(3, 'Wool', 'Soft wool', 150, 7.00, 3),
(4, 'Polyester', 'Durable polyester', 300, 4.00, 4),
(5, 'Linen', 'Breathable linen', 250, 6.00, 5),
(6, 'Denim', 'Heavy duty denim', 400, 8.00, 6),
(7, 'Rayon', 'Smooth rayon', 180, 5.50, 7),
(8, 'Nylon', 'Stretchy nylon', 220, 3.50, 8),
(9, 'Spandex', 'Flexible spandex', 140, 6.50, 9),
(10, 'Leather', 'Genuine leather', 50, 20.00, 10);

INSERT INTO Accessories (AccessoryID, AccessoryItem, AccessoryRate, AccessoryQuantity, CostSheetID) 
VALUES 
(1, 'Buttons', 0.10, 1000, 1),
(2, 'Zippers', 0.50, 500, 2),
(3, 'Threads', 0.05, 2000, 3),
(4, 'Labels', 0.20, 1500, 4),
(5, 'Tags', 0.15, 1800, 5),
(6, 'Elastic bands', 0.30, 700, 6),
(7, 'Patches', 0.25, 600, 7),
(8, 'Buckles', 0.40, 800, 8),
(9, 'Hooks', 0.35, 900, 9),
(10, 'Rivets', 0.45, 500, 10);

INSERT INTO PurchaseOrder (POID, UserID, JobID, BuyerID, FactoryID, Item, Style, Color, Quantity, OrderDt, POPrice) 
VALUES 
(1, 1, 101, 1001, 201, 'Shirt', 'Casual', 'Blue', 100, '2024-07-01', 1500.00),
(2, 2, 102, 1002, 202, 'Pants', 'Formal', 'Black', 200, '2024-07-02', 3000.00),
(3, 3, 103, 1003, 203, 'Jacket', 'Sports', 'Red', 150, '2024-07-03', 2250.00),
(4, 4, 104, 1004, 204, 'Dress', 'Evening', 'Green', 80, '2024-07-04', 2400.00),
(5, 5, 105, 1005, 205, 'Coat', 'Winter', 'Brown', 120, '2024-07-05', 1800.00),
(6, 6, 106, 1006, 206, 'Sweater', 'Casual', 'White', 180, '2024-07-06', 2700.00),
(7, 7, 107, 1007, 207, 'Skirt', 'Formal', 'Pink', 90, '2024-07-07', 1350.00),
(8, 8, 108, 1008, 208, 'Trousers', 'Office', 'Grey', 130, '2024-07-08', 1950.00),
(9, 9, 109, 1009, 209, 'Suit', 'Business', 'Navy', 70, '2024-07-09', 2100.00),
(10, 10, 110, 1010, 210, 'Shorts', 'Summer', 'Yellow', 110, '2024-07-10', 1650.00);

INSERT INTO PackList (PackListID, ShipQty, ShipMode, DeliveryDays, ETD, PLPrice) 
VALUES 
(1, 100, 'Air', 5, '2024-07-10', 2000.00),
(2, 200, 'Sea', 30, '2024-07-20', 4000.00),
(3, 150, 'Road', 10, '2024-07-15', 3000.00),
(4, 80, 'Rail', 20, '2024-07-25', 1600.00),
(5, 120, 'Courier', 7, '2024-07-12', 2400.00),
(6, 180, 'Air', 5, '2024-07-30', 3600.00),
(7, 90, 'Sea', 25, '2024-07-18', 1800.00),
(8, 130, 'Road', 12, '2024-07-22', 2600.00),
(9, 70, 'Rail', 18, '2024-07-28', 1400.00),
(10, 110, 'Courier', 6, '2024-07-14', 2200.00);

INSERT INTO Factory (FactoryID, FactoryName, FactoryAddress, FactoryEmail, FactoryContactPerson, FactoryTelNo, FactoryProduct) 
VALUES 
(201, 'Alpha Textiles', '123 Industrial Area', 'contact@alphatextiles.com', 'John Doe', '555-6789', 'Shirts'),
(202, 'Beta Garments', '456 University Road', 'info@betagarments.com', 'Jane Smith', '555-9876', 'Pants'),
(203, 'Gamma Fabrics', '789 Commerce Park', 'sales@gammafabrics.com', 'Robert Brown', '555-1235', 'Jackets'),
(204, 'Delta Designs', '321 Main Ave', 'designs@deltadesigns.com', 'Lisa Green', '555-6780', 'Dresses'),
(205, 'Epsilon Apparel', '654 5th Avenue', 'contact@epsilonapparel.com', 'Michael White', '555-9871', 'Coats'),
(206, 'Zeta Knitwear', '987 Central Blvd', 'info@zetaknitwear.com', 'Emily Davis', '555-1236', 'Sweaters'),
(207, 'Eta Clothing', '159 Fashion St', 'sales@etaclothing.com', 'David Wilson', '555-6782', 'Skirts'),
(208, 'Theta Outfits', '753 Style Rd', 'contact@thetaoutfits.com', 'Sarah Brown', '555-9872', 'Trousers'),
(209, 'Iota Suits', '852 Business Plaza', 'info@iotasuits.com', 'Brian Taylor', '555-1237', 'Suits'),
(210, 'Kappa Shorts', '963 Trendy St', 'sales@kappashorts.com', 'Karen White', '555-6783', 'Shorts');

INSERT INTO OrderDetails (POID, PackListID, PriceDiff, DeliveryDt, TransitDays) 
VALUES 
(1, 1, 500.00, '2024-07-15', 5),
(2, 2, 1000.00, '2024-07-25', 15),
(3, 3, 750.00, '2024-07-20', 10),
(4, 4, 400.00, '2024-07-30', 20),
(5, 5, 600.00, '2024-07-17', 7),
(6, 6, 900.00, '2024-08-04', 5),
(7, 7, 450.00, '2024-07-23', 25),
(8, 8, 650.00, '2024-07-27', 12),
(9, 9, 350.00, '2024-08-03', 18),
(10, 10, 550.00, '2024-07-19', 6);

INSERT INTO Roles (RoleID, Role, RoleCount) 
VALUES 
(1, 'Admin', 2),
(2, 'User', 5),
(3, 'Manager', 1),
(4, 'Supervisor', 1),
(5, 'Operator', 1);

INSERT INTO Rights (Role, Rights) 
VALUES 
('Admin', 'ALL'),
('User', 'READ_ONLY'),
('Manager', 'WRITE'),
('Supervisor', 'MODIFY'),
('Operator', 'EXECUTE');

INSERT INTO UserLogs (LoginID, SessionKey) 
VALUES 
(1, 'session_123'),
(2, 'session_456'),
(3, 'session_789'),
(4, 'session_012'),
(5, 'session_345'),
(6, 'session_678'),
(7, 'session_901'),
(8, 'session_234'),
(9, 'session_567'),
(10, 'session_890');

INSERT INTO Session (SessionKey, LoginTime, LogoutTime) 
VALUES 
('session_123', '2024-07-01 08:00:00', '2024-07-01 12:00:00'),
('session_456', '2024-07-01 09:00:00', '2024-07-01 17:00:00'),
('session_789', '2024-07-02 08:00:00', '2024-07-02 16:00:00'),
('session_012', '2024-07-03 08:00:00', '2024-07-03 18:00:00'),
('session_345', '2024-07-04 08:00:00', '2024-07-04 14:00:00'),
('session_678', '2024-07-05 08:00:00', '2024-07-05 16:00:00'),
('session_901', '2024-07-06 08:00:00', '2024-07-06 15:00:00'),
('session_234', '2024-07-07 08:00:00', '2024-07-07 13:00:00'),
('session_567', '2024-07-08 08:00:00', '2024-07-08 18:00:00'),
('session_890', '2024-07-09 08:00:00', '2024-07-09 12:00:00');

INSERT INTO User (UserID, Username, Password, Status, RoleID, LoginID) 
VALUES 
(1, 'john_doe', 'password123', 'Active', 1, 1),
(2, 'jane_smith', 'password456', 'Inactive', 2, 2),
(3, 'michael_jones', 'michael_pwd', 'Active', 3, 3),
(4, 'linda_brown', 'linda_pwd', 'Active', 4, 4),
(5, 'david_wilson', 'david_pwd', 'Inactive', 5, 5),
(6, 'susan_taylor', 'susan_pwd', 'Active', 1, 6),
(7, 'robert_miller', 'robert_pwd', 'Inactive', 2, 7),
(8, 'mary_anderson', 'mary_pwd', 'Active', 3, 8),
(9, 'james_thomas', 'james_pwd', 'Inactive', 4, 9),
(10, 'patricia_moore', 'patricia_pwd', 'Active', 5, 10);


DESC CostSheet;
DESC Job;
DESC Buyer;
DESC Fabrics;
DESC Accessories;
DESC User;
DESC Roles;
DESC Rights;
DESC UserLogs;
DESC Session;
DESC PurchaseOrder;
DESC PackList;
DESC Factory;
DESC OrderDetails;


SELECT * FROM CostSheet;
SELECT * FROM Job;
SELECT * FROM Buyer;
SELECT * FROM Fabrics;
SELECT * FROM Accessories;
SELECT * FROM User;
SELECT * FROM Roles;
SELECT * FROM Rights;
SELECT * FROM UserLogs;
SELECT * FROM Session;
SELECT * FROM PurchaseOrder;
SELECT * FROM PackList;
SELECT * FROM Factory;
SELECT * FROM OrderDetails;


-- Update Queries
UPDATE User
SET Status = 'Active'
WHERE UserID = 3;

SELECT * FROM User;

UPDATE CostSheet
SET Commission = 60.00
WHERE CostSheetID = 2;

SELECT * FROM CostSheet;

UPDATE Buyer
SET BuyerAddress = '789 Park Avenue'
WHERE BuyerID = 1001;

SELECT * FROM Buyer;

UPDATE Factory
SET FactoryContactPerson = 'Emily White'
WHERE FactoryID = 202;

SELECT * FROM Factory;

UPDATE CostSheet
SET Overheads = 180.00
WHERE CostSheetID = 1;

SELECT * FROM CostSheet;

UPDATE Factory
SET FactoryContactPerson = 'Ahmed Khan'
WHERE FactoryID = (SELECT FactoryID FROM PurchaseOrder WHERE POID = 10);

SELECT * FROM Factory;

-- Add extra records to delete that are not used by any other tables
INSERT INTO User (UserID, Username, Password, Status, RoleID, LoginID) 
VALUES (11, 'extra_user', 'extra_pwd', 'Inactive', 3, 3);

INSERT INTO Roles (RoleID, Role, RoleCount) 
VALUES (6, 'Guest', 1);

INSERT INTO Fabrics (FabricID, FabricType, FabricDescription, FabricQuantity, FabricRate, CostSheetID) 
VALUES (11, 'Polyester', 'Low quality polyester', 50, 2.00, 3);

INSERT INTO Accessories (AccessoryID, AccessoryItem, AccessoryRate, AccessoryQuantity, CostSheetID) 
VALUES (11, 'Hooks', 0.20, 200, 3);

INSERT INTO Job (JobID, JobDescription, JobStatus) 
VALUES (111, 'Job for extra task', 'Pending');

-- Delete Queries
DELETE FROM User
WHERE UserID = 11
AND UserID NOT IN (SELECT DISTINCT UserID FROM PurchaseOrder);

SELECT * FROM User;

DELETE FROM Roles
WHERE RoleID = 6
AND RoleID NOT IN (SELECT DISTINCT RoleID FROM User);

SELECT * FROM Roles;

DELETE FROM Fabrics
WHERE FabricID = 11
AND CostSheetID NOT IN (SELECT DISTINCT CostSheetID FROM CostSheet);

SELECT * FROM Fabrics;

DELETE FROM Accessories
WHERE AccessoryID = 11
AND CostSheetID NOT IN (SELECT DISTINCT CostSheetID FROM CostSheet);

SELECT * FROM Accessories;

DELETE FROM Job
WHERE JobID = 111
AND JobID NOT IN (SELECT DISTINCT JobID FROM CostSheet)
AND JobID NOT IN (SELECT DISTINCT JobID FROM PurchaseOrder);

SELECT * FROM Job;


-- SELECT All Inactive Users
SELECT * FROM User WHERE Status = 'Inactive';

-- SELECT All Completed Jobs
SELECT * FROM Job WHERE JobStatus = 'Completed';

-- SELECT Total Amount used in Fabrics of CostSheet#3
SELECT SUM(FabricQuantity * FabricRate) AS TotalFabricCost
FROM Fabrics
WHERE CostSheetID = 3;

-- SELECT Total Amount used in Accessories from All Cost sheets related to job#102
SELECT SUM(AccessoryQuantity * AccessoryRate) AS TotalAccessoryCost
FROM Accessories
WHERE CostSheetID IN (SELECT CostSheetID FROM CostSheet WHERE JobID = 102);

-- SELECT CostSheet inserted by user#2 along with all related table columns
SELECT cs.*, j.JobDescription, j.JobStatus, b.BuyerName, b.BuyerEmail, b.BuyerAddress, b.BuyerTelNo, b.BuyerCurrency,
       f.FabricType, f.FabricDescription, f.FabricQuantity, f.FabricRate,
       a.AccessoryItem, a.AccessoryRate, a.AccessoryQuantity
FROM CostSheet cs
JOIN Job j ON cs.JobID = j.JobID
JOIN Buyer b ON cs.BuyerID = b.BuyerID
LEFT JOIN Fabrics f ON cs.CostSheetID = f.CostSheetID
LEFT JOIN Accessories a ON cs.CostSheetID = a.CostSheetID
WHERE cs.UserID = 2;

-- SELECT Rights of the Role with highest RoleCount along with Role
SELECT r.Rights, r.Role
FROM Rights r
JOIN Roles rl ON r.Role = rl.Role
WHERE rl.RoleCount = (SELECT MAX(RoleCount) FROM Roles);

-- SELECT Date with most logged in users
SELECT DATE(s.LoginTime) AS Date, COUNT(s.SessionKey) AS LoginCount
FROM Session s
GROUP BY DATE(s.LoginTime)
ORDER BY LoginCount DESC
LIMIT 1;

-- SELECT All buyers whose Orders will be delivered before '2024-07-30'
SELECT DISTINCT b.*
FROM Buyer b
JOIN PurchaseOrder po ON b.BuyerID = po.BuyerID
JOIN OrderDetails od ON po.POID = od.POID
WHERE od.DeliveryDt < '2024-07-30';

-- SELECT AVG(TransitDays) for all the Orders to be delivered by Air
SELECT AVG(od.TransitDays) AS AvgTransitDays
FROM OrderDetails od
JOIN PackList pl ON od.PackListID = pl.PackListID
WHERE pl.ShipMode = 'Air';

-- Total Cost of Orders for each Buyer
SELECT b.BuyerName, SUM(po.POPrice) AS TotalCost
FROM Buyer b
JOIN PurchaseOrder po ON b.BuyerID = po.BuyerID
GROUP BY b.BuyerName;

-- List all CostSheets with their respective Fabrics and Accessories details
SELECT cs.*, f.FabricType, f.FabricDescription, f.FabricQuantity, f.FabricRate,
       a.AccessoryItem, a.AccessoryRate, a.AccessoryQuantity
FROM CostSheet cs
LEFT JOIN Fabrics f ON cs.CostSheetID = f.CostSheetID
LEFT JOIN Accessories a ON cs.CostSheetID = a.CostSheetID;
